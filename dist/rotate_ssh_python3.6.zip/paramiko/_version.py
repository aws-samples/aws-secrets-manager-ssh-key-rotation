__version_info__ = (2, 6, 0)
__version__ = ".".join(map(str, __version_info__))
